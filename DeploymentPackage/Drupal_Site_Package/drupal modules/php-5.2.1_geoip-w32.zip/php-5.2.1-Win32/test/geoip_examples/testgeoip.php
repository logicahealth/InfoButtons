<head><title>Check for GeoIP properties</title></head>
<body>
<h2>Check for GeoIP properties</h2>
<?php
  // Simple script which displays the internal functions of php_geoip.
  // v0.10 07-May-2006, by G. Knauf <efash@gmx.net>
  if (isset($_GET['viewsource'])) { highlight_file($_SERVER['SCRIPT_FILENAME']); die; };
  extension_loaded('geoip') or die("<font color=red><b>Error: 'geoip' extension not loaded!</b></font>"); 

  echo "<b>GeoIP Database Conf: <font color=green>" . ini_get('geoip.database_standard') . "</font></b><br>\n";
  echo "<b>GeoIP Database Info: <font color=blue>" . geoip_database_info() . "</font></b><br>\n";
  if (isset($_POST['submit'])) { 
    echo "<pre>\n";
    echo "Query Host   : " . $_POST['host'] . "\n";
    echo "Country Code : " . geoip_country_code_by_name($_POST['host']) . "\n";
    echo "Country Name : " . geoip_country_name_by_name($_POST['host']);
    if (isset($_POST['full'])) { 
      echo geoip_org_by_name($_POST['host']);
      echo geoip_region_by_name($_POST['host']);
      echo geoip_id_by_name($_POST['host']);
      $result = geoip_record_by_name($_POST['host']);
      print_r($result);
    }
    echo "</pre>\n";
  } else {
?>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<b>Enter Host Address:</b><br>
<input type="text" name="host" size="40" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
Full Info <input type="checkbox" name="full" value="1">
<p><input type="submit" name="submit" value="submit">
</form>
<?php
  include "footer.inc";
}
?>

