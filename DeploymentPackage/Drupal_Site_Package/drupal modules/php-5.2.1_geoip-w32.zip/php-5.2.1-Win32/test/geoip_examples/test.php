<head><title>Show internal functions</title></head>
<body>
<h2>Show internal functions</h2>
<?php
  // Simple script which displays the internal functions of the specified extension.
  // v0.10 09-Feb-2006, by G. Knauf <efash@gmx.net>
  if (isset($_GET['viewsource'])) { highlight_file($_SERVER['SCRIPT_FILENAME']); die; };
  $myext = 'geoip';
  extension_loaded($myext) or die("<font color=red><b>Error: " . $myext . " extension not loaded!</b></font>"); 

  echo "<b>Extension: <font color=blue>" . $myext . "</font></b>\n";

  $result = get_extension_funcs($myext);
  echo "<pre>\n";
  print_r($result);
  echo "</pre>\n";

?> 


