Quick Install of the PHP GeoIP Extension
========================================

PHP version    : 5.2.1
Apache version : 2.x

This extension is build for PHP 5.2.1 as downloadable from the PHP site,
and will probably not work with other versions!
It is mandatory that you download the GeoIP database files in order to
get the extension working, and also look for further documentation:
http://www.maxmind.com/

Extract the files from this archive with full pathnames so that subdirs 
are created; then just copy the extension to c:/php5/ext/.
Finally edit c:/php5/php.ini and add this line to load the extension:
extension=php_geoip.dll

then reload PHP or reboot your server.
Finally check with phpinfo() that the module is loaded.

Known bugs:
- none yet ...

